var xpos = 100, size = 20;
function setup() {
  createCanvas(520, 520);
  //stroke(255);
  //strokeWeight(3);
  noStroke();
  noFill();
  
}

function draw() {
  //background(0);
  //map(value, initial range start , initial range end, new range start, new range end);
  var bgx= map(mouseX, 0, 520, 0, 255);
  var bgy= map(mouseY, 0, 520, 0, 255);
  background(bgx);//varying background color
  for(var j = 0; j <6; j++){
    if(j==0){fill(255 - bgx,0,0);}//varying reds
    if(j==1){fill(255 - bgx,255- bgy,0);}//varying reds & greens
    if(j==2){fill(0,255 - bgy,0);}//varying greens
    if(j==3){fill(0, 255 - bgy,255);}
    if(j==4){fill(0,0,255-((bgy + bgx)/2));}
    if(j==5){fill(255 - bgx,0,255-((bgy + bgx)/2));}
    for(var i = 0; i< height; i+= 50){
      rect(xpos*j,i,size,size);
    }
  }
}