var angle = 0;

function setup() {
  createCanvas(400, 400);
  background(220);
}

function draw() {
  translate(mouseX, mouseY);
  rotate(angle);
  rect(-15, -15, 30, 30);
  angle += .1;
}