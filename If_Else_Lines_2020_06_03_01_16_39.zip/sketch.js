function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(127);
  strokeWeight(10);
  stroke(150);
  line(40,0,70, height);

  if(mouseIsPressed == true){
    stroke(0);
  }
  else{
    stroke(255);
  }
  line(0,70,width, 50);
}