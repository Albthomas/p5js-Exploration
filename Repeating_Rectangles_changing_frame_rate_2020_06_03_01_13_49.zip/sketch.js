//Global Variables
var rectx, recty, rectw, recth;
var x = 0, y = 0;
var randr, randb,randg, opacity;

function setup() {
  createCanvas(400, 400);
  background(220);
}

function draw() {
  //background(220);
  x = x+1;
  frameRate(x);
  
  //Local Variables
  //var myVariable = 150;
  //print(myVariable);
  randr = random(255);
  randb = random(255);
  randg = random(255);
  opacity = random(255);
  
  fill(randr, randg, randb, opacity); //4th parameter is alpha - sets opacity
  rectx = random(width);
  recty = random(height);
  rectw = random(400);
  recth = random(400);
  rect(rectx, recty, rectw, recth);
  if(x == 60){
    x = 0;
    y = y+1;
  }
  if(y == 5){
    background(220);
    y = 0;
    
  }
  print(x);
}