var bx, bsize, bspeed, xdir;
var by, ydir, byspeed;
var shade, c1, c2, c3;

function setup() {
  createCanvas(400, 400);
  bx = width/2;
  bsize = width/4;
  bspeed = 2;
  xdir = 1;
  by = height/2;
  ydir = 1;
  byspeed = 3;
  c1 = 255;
  c2 = 255;
  c3 = 255;
  
}

function draw() {
  background(220);
  fill(c1, c2,c3);//color of ball
  //Make Ball Move
  ellipse(bx, by, bsize, bsize );
  if(bx < width && xdir == 1){//when the ball is moving to the right
    bx = bx+(xdir* bspeed);
  }
  if(by < height && ydir == 1){
    by = by +(ydir*bspeed);
  }
  if(bx + bsize/2==width || bx- bsize/2==0){//allows ball to switch directions
    c1 = random(255);
    c2 = random(255);
    c3 = random(255);
    xdir = xdir*(-1);
  }
  if(by + bsize/2 == height || by- bsize/2 == 0){
    c1 = random(255);
    c2 = random(255);
    c3 = random(255);
    ydir = ydir*(-1);
  
  }
  if(bx >0 && xdir == -1){//when ball is moving to the left
    bx = bx+(xdir* bspeed);
  }
  if(by >0 && ydir == -1){
    by = by+(ydir* byspeed);
  }
  /*
  if(mouseIsPressed){
    
  }
  
  //*/
 // else{}
  
  
}