function setup() {
  createCanvas(400, 400,100);
  
}

function draw() {
  //simple house drawing
  background(100);//gray background
  stroke(0,0,0); //black stroke
  strokeWeight(1);//gives pixel weight - very small outline
  line(0,300, 400, 300);//this is the ground
  fill (179,59,0);//rgb(179,59,0), color of house
  rect(125, 150, 150, 150);//creates body of house
  fill(0,0,130);// color of roofing
  triangle(200, 80, 120,155, 280, 155);//this is the roof 
  fill(255,255,255);//color of windows
  ellipse(width/2, height/2, 20, 40);//circle window
  quad(150, 220, 175, 220, 180, 270, 145, 270);//side window
  quad(225, 220, 250, 220, 255, 270, 220, 270);//side window
  fill(0,100,0);
  rect(0,300, 400, 100);//grass
  fill(77,25,0);//door color
  rect(190, 260, 20, 40);// door
  beginShape();
  //path vertices
  vertex(300,400);
  vertex(210, 300);
  vertex(190, 300);
  vertex(100, 400);
  endShape(CLOSE);
  fill(0,0,0);//black road
  rect(0,380, 400, 100);//road
  fill(255,255,255);
  strokeWeight(0);
  //cloud that moves with mouse
  ellipse(mouseX, mouseY, 30, 30);
  ellipse(mouseX +10, mouseY-3, 22, 30);
  ellipse(mouseX +20, mouseY, 30, 30);
  ellipse(mouseX +15, mouseY-12, 22, 30);
  //adds a quick moving second cloud that you have less control of
  let r = random(50)
  ellipse(mouseX+r, mouseY, 30, 30);
  ellipse(mouseX +10+r, mouseY-3, 22, 30);
  ellipse(mouseX +20+r, mouseY, 30, 30);
  ellipse(mouseX +15 +r, mouseY-12, 22, 30);
}