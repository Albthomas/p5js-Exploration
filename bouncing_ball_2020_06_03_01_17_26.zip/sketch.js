//Variable Declarations:
var ypos,w,e,sky,grd;

function setup() {
  createCanvas(400, 400);
  //Initialiization:
  ypos = 0;//y position of circle
  w = 20;//weight of strokes
  e = .05;//easing of circle - decelerates to an edge
  sky = 10;//location of "sky"
  grd = height -10;//location of "ground"
  direction = 1
}

function draw() {
  background(220);
  stroke(50);
  strokeWeight(w);
  line(0, grd, width, grd);
  
  stroke(200);
  line(0,sky,width, sky);

  
  fill(0,25);
  noStroke();
  ellipse(width/2, ypos, 20,20);
  if(ypos< width&& direction == 1){
  ypos += e*(grd - ypos);  
  }
  if(ypos== width|| ypos == 0){
    direction *=(-1);
  }
  if(ypos<0 && direction == -1){
    ypos += e*(sky-ypos);
  }
  
}