//Condtitional Statments are statements that dictate future actions in you code. This includes deciding if certain blocks of code are run while others are skipped over depending on if certain conditions are met.
var x = 0
function setup() {
  createCanvas(400, 400);
  frameRate(30);
}

function draw() {
  //the following shows the basics of a conditional statement 
  //with the if-else construct
  //There is a condition that is being tested within the if block
  //there are 2 alternate routes for the code to take
  
  if(x<256){
    background(x);//background color gets lighter with each iteration
    x++;
  }
  else{
    x = 0;//background color returns to black
    background(x);
  }
  
}