function setup() {
  createCanvas(400, 400);
  background(204);
}

function draw() {
  rotate(mouseX,100);
  rect(40,30,160,20);
}