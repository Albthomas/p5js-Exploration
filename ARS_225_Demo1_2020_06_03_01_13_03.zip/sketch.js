function setup() {
  createCanvas(600, 600); //number of x and y pixels
}

function draw() {
  
  background(220); //Comments are double slashes
  stroke(255,0,0); //gives color for the point
  strokeWeight(5);//gives pixel weight 
  point(300,200); //put down the x and y coordinates for the pixel point
  stroke(0,175,0); //changes stroke color
  point(50,50);
  stroke(0,0,255);
  point(550,50);
  let x = 0;
  let y = 0;
  for(i = 0; i< 100; i++){
  point(x,y);
    x = x+1;
    y = y+1;
  }
  stroke(100,200,0);
  line(0,100,600,100);// line function - start x,y then end x,y
  stroke(0, 200, 200);
  line(200,50, 200, 500);
  //Quad
  fill(0,0,255,200);
  quad(50, 250, 300, 250, 325, 350, 75, 300);
  //Triangle
  fill(255,175, 0, 150);
  triangle(200,50,500, 150, 300, 350);
 //Rectangle
  rect(500, 300, 75, 25);
  //Ellipse
  ellipse(20, 20, 150, 200);
  ellipse(width/2, height/2, 400, 200);
  
  //Custom shapes:
  fill(255,255,0);
  stroke(0)
  strokeWeight(5);
  beginShape();
  //place vertices in this area:
  vertex(400,100);
  vertex(200, 300);
  vertex(50, 50);
  vertex(800,100);
  vertex(250, 300);
  vertex(50, 100);
  endShape(CLOSE);
  
  ellipse(mouseX, mouseY, 10, 30);
  
  fill(random(255));
  rect(400, 200, 400, 60);
  
  
}