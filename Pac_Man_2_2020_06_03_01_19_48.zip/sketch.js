//Variable Declaration
var pAngle, pOpen;
var pSize, pX, pY;// size and position of pac man
var pAngleSp;//speed angle of mouth opens or closes
var pRot; // rotation angle of pacman arc
var pSp;
var direction; //dictates the direction. 
              //0 = left, 1= right, 2 = up, 3 = down
function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
  fill(255,255,0);
  noStroke();
  //Initialize Variables
  pAngle = 30;
  pOpen = false;
  pSize = width/8;
  pX = width/2;
  pY = height/2;
  pAngleSp = 2;
  pRot = 0;
  pSp = 3;
  direction = 5; //will not move to start
}

function draw() {
  background(0);
  
  //INCREMENT ARC:
  if(pAngle >= 45 ){
    pOpen = false;
  }
  if(pAngle<= 0){
    pOpen = true;
  }
  if(pOpen == false){
    pAngle-= pAngleSp;
  }
  else{
    pAngle+= pAngleSp;
  }
  
  //Determine if key on keyboard is being pressed
  //will change direction of PacMan is so
  if(keyIsPressed){
    if(keyCode === LEFT_ARROW){
      pRot = 180;
      direction = 0;
     // pX-= pSp;
      
    }
    else if(keyCode === RIGHT_ARROW){
      pRot = 0;
      direction = 1;
     // pX+=pSp;
      
      
    }
    else if(keyCode === UP_ARROW){
      pRot = 270;
      direction = 2;
     // pY-=pSp;
      
    }
    else if(keyCode === DOWN_ARROW){
      pRot = 90;
      direction = 3;
      //pY+=pSp;
      
   }
    print(pRot);
  }
  //MOVEMENT DIRECTION
  if(direction == 0){//move left
    pX -= pSp;
    if(pX <= -pSize/2){
        pX = width+pSize/2;
      }
  }
  else if(direction == 1){//move right
    pX += pSp;
    if(pX>= width + pSize/2){
        pX = -pSize/2; 
      }
  }
  else if(direction == 2){//move up
    pY -= pSp;
    if(pY <= -pSize/2){
         pY = height + pSize/2;
      }
  }
  else if (direction == 3){//move down
    pY+= pSp;
    if(pY >= width + pSize/2){
        pY = -pSize/2;
      }
  }
  
  
  setOrigin(pX, pY);
  rotate(pRot);
  
  //DRAW PAC MAN ARC
  //arc(x,y,width,height, start angle, stop angle);
  //arc(pX, pY, pSize, pSize, pAngle, -pAngle);
  arc(0, 0, pSize, pSize, pAngle, - pAngle);
}
//Function to reset origin point with Translate();
function setOrigin(x, y){
  //print("hello");
  //print("("+ x + ":"+ y + ")");
  translate(x,y);
}

