var bx, bsize, bspeed, bdir;

function setup() {
  createCanvas(400, 400);
  bx = width/2;
  bsize = width/4;
  bspeed = 2;
  bdir = 1;
  
}

function draw() {
  background(220);
  //Make Ball Move
  ellipse(bx, height/2, bsize, bsize );
  if(bx < width && bdir == 1){//when the ball is moving to the right
    bx = bx+(bdir* bspeed);
  }
  if(bx + bsize/2==width || bx- bsize/2==0){//allows ball to switch directions
    bdir = bdir*(-1);
  }
  if(bx >0 && bdir == -1){//when ball is moving to the left
    bx = bx+(bdir* bspeed);
  }
  /*
  if(mouseIsPressed){
    
  }
  
  //*/
 // else{}
  
  
}