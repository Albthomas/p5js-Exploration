//DECLARE VARIABLES AND ARRAYS
var cir = 100; //number of circles
var d = []; //diameter array
var x = []; //you create an x-position array here
var y = []; //you create a y-position array here
var sp=[]; //you create a speed in x direction here
var cFill = []; //you create fill color array here
var type;
var direction; //0 = none, 1 = left, 2 = right, 3 = up, 4 = down
function setup(){
 createCanvas(600, 600);
 background(0);
 
 //USE FOR LOOP TO INITIALIZE ARRAYS
 //THE NUMBER OF TIMES THAT THE FOR LOOP LOOPS IS THE NUMBER OF CIRCLES
 var r, g, b, a;
  for(var i = 0; i < cir; i++){ //cir limits the number of times the loop loops
   
 d[i] = random(width); //the loop generates number of diameters needed for each circle
 //you should initialize the remaining 4 arrays
  x[i] = random(width);
  y[i] = random(height);
   sp[i] = random(5);
    sp[i] += 1; //don't want a sp = 0
   r = random(255);
    g = random(255);
    b = random(255);
    a = random(255);
   cFill[i] = color(r,g,b,a);
    type = -1;
 
 }
}

function draw(){
  background(0);
 //in the draw function, you need to create another for loop
 //to set the fill color, draw the circles, and make them move
 //you should also make the circles wrap around when they
 //reach the right edge as we did in class this week
 
  
  /* if(keyIsPressed){
    if(keyCode == LEFT_ARROW){
      for(var i = 0; i< cir; i++){
      
      }
    }
  }*/
  if(keyIsPressed ){
    if((keyCode == ENTER)){//changes shape to square
      type *= (-1);
    }    
    if(keyCode == LEFT_ARROW){//move left
      direction = 1;
    }
    else if(keyCode == RIGHT_ARROW){//move right
      direction = 2;
    }
    else if(keyCode == UP_ARROW){//move up
      direction = 3;
    }
    else if(keyCode == DOWN_ARROW){//move down
      direction = 4;
    }
    else if(keyCode == 80){//keycode for 'p', pauses motion
      direction = 0;
    }
    
  }
  for(var i = 0; i<cir; i++){
    fill(cFill[i]);
    
    if(type == -1){
      ellipse(x[i], y[i], d[i], d[i]);//
    }
    else{
      square(x[i],y[i],d[i])
    }
    if(direction == 1){//left
      x[i] -= sp[i];
      if(x[i]<= -d[i]/2){
        x[i] = width + d[i]/2;
      }
    }
    else if(direction == 2){//right
      x[i] +=sp[i];
      if(x[i]>= width + d[i]/2){
        x[i] = - d[i]/2;
      }
    }
    else if(direction == 3){//up
      y[i] -= sp[i];
      if(y[i]<= -d[i]/2){
        y[i] = width + d[i]/2;
      }  
    }
    else if(direction == 4){//down
      y[i] +=sp[i];
      if(y[i]>= height + d[i]/2){
        y[i] = - d[i]/2;
      }
    }
    
  }
  
}