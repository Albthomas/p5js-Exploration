//Declare Variables
var ang; // what is the arc of the angle
var opn; // is it opening or closing
var size; // size of arc
var spMouth;// speed of mouth
var spMove; // speed of motion
var x; //x position of arc
var y; // y position of arc

function setup() {
  createCanvas(400, 400);
  fill(255, 255, 0);
  noStroke();
  angleMode(DEGREES);
  //Initialize Functions
  ang = 0; // closed mouth
  opn = true;// mouth is being opened 
  size = width/4;//size of shape is relative to canvas
  spMouth = 2;// speed of opening
  spMove = 5;// speed of movement
  x = width/2;// starting x
  y = height/2;// starting y
  
  
}

function draw() {
  background(0);//background
  if(x == width+ size/2){x = -size/2;}//creates infinite motion of pacman
  
  //Draw Arc
  arc(x, y, size, size,ang,-ang);
  //Determine if arc is opening or closing
  
  if(open == true){
     ang = ang+spMouth;
    if(ang >= 45){
      open = false;
    }
  }
  else{
    ang = ang-spMouth;
    if(ang <= 0){
    open = true;
    }
  }
  x+= spMove;//incrememt x position
  
  
  
  
  
}