var xpos = 100, ypos = 25, size = 50;

function setup() {
  createCanvas(400, 400);
  background(0);
  stroke(255);
  strokeWeight(5);
  noFill();
}

function draw() {
  rect(xpos+ random(100),ypos + random(100), size, size);
  
  
  for(var i = 0; i< 5; i++){
    print(i);
    rect(xpos * (i), ypos + 300, size, size);
  }
}