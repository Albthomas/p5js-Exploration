//Declare Variables
var frame;
var shade;
var waitTime;
function setup() {
  createCanvas(400, 400);
  background(204);
  //Initialize Variables
  frame = 30;
  frameRate(30);
  waitTime = 0;
}

function draw() {
  shade = random(255);
  stroke(255,0,0);
  fill(shade,shade,shade, 30);
  translate(mouseX,mouseY);
  rect(0,0,30,30);
  
  if(mouseIsPressed && frame != 0){
    frameRate(0);
    frame = 0;
  }
  
}