var xpos,ypos,d,xdis;
function setup() {
  createCanvas(400, 400);
  xpos = width/2;
  ypos = height/2;
  d = 12;//circle radius
}

function draw() {
  background(220);
  
  xdis = dist(xpos, ypos, mouseX, mouseY);
  if(xdis <= d/2){
    d++;
    //fill(0);
  }
  else{
    d = 12;
    //fill(255);
  }
  if(d == 50){ d = 12;}
  ellipse(xpos,ypos,d,d);//creates a circle since both height & length are equal
}