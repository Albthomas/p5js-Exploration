var xrect = 300;
var wrect = 200;
var xpos;
function setup() {
  createCanvas(600, 600);
  noStroke();
}

function draw() {
  background(220);
  xpos = mouseX;
  
  if(xpos>=xrect && xpos <= xrect+wrect){fill(0);}
  else{fill(255);}
  
  rect(xrect,0,wrect,height);
}