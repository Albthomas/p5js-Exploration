var h, m, sec;//current time
var HeadX, HeadY// Center point values for head
var shaddowLength, shaddowDirection//properties of cast shaddow of man
var headheight; //height of head
var headDiameter; //Diameter of the Head
var AgeShaddowControl; //Uses the hours to help dictate the starting point of the shaddow

//var morning;//equals 1 if morning
//var armMaxX;
//var armMinX;
function setup() {
  createCanvas(400, 400);
  AgeShaddowControl = 20;
}

function draw() {
  //update time values:
  h= hour();
  m = minute();
  sec = second();//(0 to 59)
  //Set Head x coordinate using sec variable
  HeadX = width*sec/59;
  
  //Find shaddow location using m variable
  if(m<30){//0 to 29
    shaddowLength = 200 - 100*m/29 ;
    shaddowDirection= 1;//means shaddow is in front of man
  }else{//30 to 59
    shaddowLength = 100 + 100*(m-30)/29;
    shaddowDirection = -1;//means shaddow is behind man
  }
  //Set background color with m
  if(m<29){//first half of day
    background(0,0,100+ m*255/29);//goes from black to white as day continues
  }
  else{//second half of day
    background(0,0,100+(59-m)*255/29);//goes from white to black
  }
  //Create Cast Shaddow
  noStroke();
  fill(0);
  if(h <4){
    AgeShaddowControl = 10 ;
  }
  else{
    AgeShaddowControl = 20 ;
  }
  if(shaddowDirection == 1){//shaddow in front of man
    rect(HeadX - AgeShaddowControl, 370, shaddowDirection*shaddowLength, 30);
    
  }
  else{//shaddow behind man
    rect(HeadX+AgeShaddowControl, 370, shaddowDirection*shaddowLength, 30);
  }
  
  fill(255);
  //Place the Body
  if(h<4){//hours 0 to 3, baby body
     headDiameter = 20;
    stroke(255);
    strokeWeight(5); 
    HeadY = 340;
    circle(HeadX, HeadY, headDiameter);
    
    line(HeadX,HeadY,HeadX - 50, HeadY+15);//body line
    line(HeadX - 25, HeadY+10, HeadX, HeadY+30);//right arm
    line(HeadX - 25, HeadY+10,HeadX - 10, HeadY+30);//left arm
    line(HeadX-50,HeadY+15, HeadX-50,HeadY+30);//right leg
    line(HeadX-50,HeadY+15, HeadX-55,HeadY+30);//left leg
    line(HeadX-50, HeadY +30, HeadX-70, HeadY+30);//bottom of legs
  }
  else if(h<8){//hours 4 to 7, todler body
    headDiameter = 25;
    noStroke();
    HeadY = 280;
    circle(HeadX, HeadY, headDiameter);
    
    strokeWeight(5);
    stroke(255);
    line(HeadX,HeadY,HeadX, HeadY+60);//body line
    line(HeadX, HeadY+20, HeadX+10, HeadY+50);//right arm
    line(HeadX, HeadY+20, HeadX - 10, HeadY+50);//left arm
    line(HeadX,HeadY+60, HeadX+15,HeadY+90);//right leg
    line(HeadX,HeadY+60, HeadX-15,HeadY+90);//left leg
    
  }
  else if(h<12){//hours 8 to 11, child body
    headDiameter = 50;   
    noStroke();
    HeadY = 260;
    circle(HeadX, HeadY, headDiameter);
    
    strokeWeight(5);
    stroke(255);
    line(HeadX,HeadY,HeadX, HeadY+80);//body line
    line(HeadX, HeadY+40, HeadX+10, HeadY+70);//right arm
    line(HeadX, HeadY+40, HeadX - 10, HeadY+70);//left arm
    line(HeadX,HeadY+80, HeadX+15,HeadY+110);//right leg
    line(HeadX,HeadY+80, HeadX-15,HeadY+110);//left leg
  }
  else if(h<16){//hours 12 to 15, young adult body
    headDiameter = 100;        
    noStroke();
    HeadY = 140;
    circle(HeadX, HeadY, headDiameter);
    
    strokeWeight(10);
    stroke(255);
    line(HeadX,HeadY,HeadX, HeadY+170);//body line
    line(HeadX, HeadY+80, HeadX+25, HeadY+150);//right arm
    line(HeadX, HeadY+80, HeadX - 25, HeadY+150);//left arm
    line(HeadX,HeadY+170, HeadX+15,HeadY+230);//right leg
    line(HeadX,HeadY+170, HeadX-15,HeadY+230);//left leg
  }
  else if(h<20){//hours 16 to 19, old adult body
    headDiameter = 100;
    noStroke();
    HeadY = 140;
    circle(HeadX, HeadY, headDiameter);
    
    strokeWeight(10);
    stroke(255);
    line(HeadX-20,HeadY,HeadX-20, HeadY+170);//body line
    line(HeadX-20, HeadY+80, HeadX+5, HeadY+150);//right arm
    line(HeadX-20, HeadY+80, HeadX - 45, HeadY+150);//left arm
    line(HeadX-20,HeadY+170, HeadX+5,HeadY+230);//right leg
    line(HeadX-20,HeadY+170, HeadX-35,HeadY+230);//left leg
  }
  else {//hours 20 to 23, elderly body
    headDiameter = 100;
    noStroke();
    HeadY = 140;
    circle(HeadX, HeadY, headDiameter);
    
    strokeWeight(10);
    stroke(255);
    line(HeadX-20,HeadY,HeadX-20, HeadY+170);//body line
    line(HeadX-20, HeadY+80, HeadX+15, HeadY+140);//right arm
    line(HeadX-20, HeadY+80, HeadX - 45, HeadY+150);//left arm
    line(HeadX-20,HeadY+170, HeadX+5,HeadY+230);//right leg
    line(HeadX-20,HeadY+170, HeadX-35,HeadY+230);//left leg
    line(HeadX+15, HeadY+140,HeadX+15, HeadY+230);//right arm
    
  }
}