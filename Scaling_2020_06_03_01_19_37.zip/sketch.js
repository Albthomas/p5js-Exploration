function setup() {
  createCanvas(400, 400);
  background(220);
}

function draw() {
  translate(mouseX, mouseY);
  scale(mouseX/60);
  rect(-15, -15, 30, 30);
}