//This program has the fill color change to black if the mouse is in the rectangle
//otherwise the fill is white
//Declare Variables
//properties of rectangle
var xrect = 200;
yrect = 50;
var wrect = 200;
var hrect = 300;
//posibition of mouse:
var xpos;
var ypos;

function setup() {
  createCanvas(600, 600);
  
}

function draw() {
  background(220);
  xpos = mouseX;
  ypos = mouseY;
  if(xpos>= xrect && xpos <= xrect+wrect&& ypos>=yrect && ypos<= yrect+hrect){ fill(0);}
  else{fill(255);}
  rect(xrect, yrect, wrect, hrect);
  
  
  
}