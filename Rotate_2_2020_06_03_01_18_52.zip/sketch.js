function setup() {
  createCanvas(400, 400);
  background(204);
}

function draw() {
  rotate(mouseX/100);
  rect(-80,-10,160,20);
}