var x;
  x = 0;
  let y = 0;
  let z = 0;
function setup() {
  createCanvas(600, 600);
  background(220);
  
}

function draw() {
  
  stroke(15);
  fill(255, 0 , 255);
  rect(x,40,200,100);
  
  if(y < 6){
    y = y+1;
  }
  else{
    y = 0;
  }
  print("before z = " +z);
  if(z == 0){
    let z = 1;
    print("loop z = 0 entered");
  }
  if(z == 1){
    let z = 0;
    print("loop z = 1 entered");
  }
  
  print("x = " + x);
  print("y = " + y);
  print("z = " + z);

  
}
